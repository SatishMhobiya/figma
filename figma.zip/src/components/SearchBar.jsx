const SearchBar = ()=>{
    return(
    
        <div style={{position:"fixed"}}>
        <div style={{ display:"flex", justifyContent:"center", marginLeft:"20px", marginRight:"20px", marginTop:"20px"}} className="ui icon input">
            <input type="text" placeholder="Search for contacts"/>
            <i className="search icon"></i>
        </div>
    </div>
       
    )
}

export default SearchBar();