import SupplierMessage from "./supplier/SupplierMessage";
import SupplierMessageDetails from "./supplier/SupplierMessageDetails";
import SupplierUpdateDetails from "./supplier/SupplierUpdateDetails";

const ReadContent = ()=>{
    return(
        <div style={{ padding:"50px"}} className="border border-grey rounded">
            <div className="">
                <button class="btn btn-dark">
                    <span className="p-2">
                    <i class="bi bi-envelope-fill"></i>
                    </span>
                    Gmail
                </button>
            </div>

            <div style={{display:"flex", justifyContent:"space-between"}} className="mt-5">
                <SupplierUpdateDetails/>
                <SupplierMessageDetails/>
            </div>
            <div className="mt-5">
                <SupplierMessage/>
            </div>
        </div>
    )
}

export default ReadContent;