const TopBar = ()=>{
    return(
        <div style={{ position: "sticky", top: "0", backgroundColor: "#f7f8fc", marginBottom:"30px"}}>
                 
        <div style={{ display: "flex", justifyContent: "space-between" , marginInline:"20px"}}>
            <h2 style={{marginTop:"20px"}}>Communications History</h2>
            <div  style={{marginTop:"20px", marginRight:"20px", width:"300px"}} className="ui icon input">
                <input  type="text" placeholder="Search..."/>
                <i className="search icon"></i>
            </div>
        </div>
    
        </div>
    )
}

export default TopBar;