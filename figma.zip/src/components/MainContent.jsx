import ReadContent from "./ReadContent"
import TopBar from "./TopBar"


const MainContent = () => {
    return (
        <div style={{background: "#f7f8fc"}}>
            <TopBar/>
            <div>
                {[0,1,2,3].map((item)=>{
                    return <ReadContent/>
                })}
            </div>
        </div>


    )
}

export default MainContent