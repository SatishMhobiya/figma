import { Dropdown } from "bootstrap";

import { DropdownList } from "react-widgets/cjs";
import "react-widgets/styles.css";
import SearchBar from "./SearchBar";

const SideBar = ()=>{
    const searchNames = ['Sydney', 'Melbourne', 'Brisbane', 
    'Adelaide', 'Perth', 'Hobart'];
    return(
        <div style={{background:"lightGrey"}}>
            <div style={{position:"fixed"}}>
                <div style={{ display:"flex", justifyContent:"center", marginLeft:"20px", marginRight:"20px", marginTop:"20px"}} className="ui icon input">
                    <input type="text" placeholder="Search for contacts"/>
                    <i className="search icon"></i>
                </div>
            </div>
            {/* <DropdownList
                defaultValue="Yellow"
                data={["Red", "Yellow", "Blue", "Orange"]}
            />; */}
        </div>
    )
}

export default SideBar;