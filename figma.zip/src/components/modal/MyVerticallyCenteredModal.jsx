import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Modal } from 'react-bootstrap';

function MyVerticallyCenteredModal(props) {
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Email
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div>
                    <div>
                        <span><b>To:</b> &emsp; &emsp; &emsp;Jay Shetty</span><hr />
                    </div>
                    <div>
                        <span><b>CC:</b>&emsp; &emsp; &emsp;Pelpola Vijiya, Caroll</span><hr />
                    </div>
                    <div>
                        <span><b>Subject:</b> &emsp; Internal Milestone Update neede</span><hr />
                    </div>
                    <div>
                        <div>
                            Dear Jayasinghe Sangakkara,<br /><br />

                            We need an urgent update for PO # 12087633979 as we have not heard from you. Please provide us an update of the delivery date ASAP.<br />

                            <br />Jones Ferdinand<br />
                            Brandix Product Manager
                        </div>
                    </div>
                    <div className='mt-5'>
                        <button class="btn btn-primary">
                            <span className='p-2'>
                        <i class="bi bi-box-arrow-up-right"></i></span>
                            fill in form
                        </button>
                        <hr style={{width:"20%"}}/>
                    </div>
                    <div>
                        <span><b>Jones Ferdinand</b></span><br/>
                        <span>Product Manager</span><br/>
                        <span>Brandix</span><br/>
                        <span>900090009</span>
                    </div>
                    <div>
                        <div style={{display:"flex", justifyContent:"space-around", marginTop:"10px"}}>
                        <Button variant="light" className="border border-dark">Internal Milestone Update</Button>
                        <Button variant="light" className="border border-dark">External Risk Update</Button>
                        <Button variant="light" className="border border-dark">Shipping Information</Button>
                        </div>
                    </div>
                </div>
            </Modal.Body>
            <Modal.Footer>
                <Button onClick={props.onHide}>Close</Button>
            </Modal.Footer>
        </Modal>
    );
}

export default MyVerticallyCenteredModal;