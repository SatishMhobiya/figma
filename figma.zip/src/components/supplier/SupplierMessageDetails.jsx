const SupplierMessageDetails = ()=>{
    return(
        <div>
            <span>Received: </span><br/>
            <span>Last Opened: </span><br/>
            <span>Opened 7 times</span>
        </div>
)}

export default SupplierMessageDetails;