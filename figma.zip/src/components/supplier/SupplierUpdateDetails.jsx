const SupplierUpdateDetails = ()=>{
    return(
        <div>
            <h5><b>FW: Supplier Update</b></h5>
            <h5>P/O#lkd646413251</h5>
        </div>
    )
}

export default SupplierUpdateDetails;