const SupplierMessage = ()=>{
    return(
        <div>
           <div>
           Dear Jayasinghe Sangakkara,<br/><br/>

            We need an urgent update for PO # 12087633979 as we have not heard from you. Please provide us an update of the delivery date ASAP.<br/>
            
            <br/>Jones Ferdinand<br/>
            Brandix Product Manager
           </div>

           <div className="mt-5">
               <div style={{display:"flex", justifyContent:"space-between", width:"300px"} }>
                    <a href="#">Reply</a>
                    <a href="#">Reply All</a>
                    <a href="#">Forward</a>
               </div>
           </div>
        </div>
)}

export default SupplierMessage;