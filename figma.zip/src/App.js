import logo from './logo.svg';
import './App.css';
import SideBar from './components/SideBar';
import MainContent from './components/MainContent';
import ComposeGmailModel from './components/modal/ComposeGmailModal';

function App() {
  return (
    <div>
      <div style={{ height: "100vh", display: "grid", gridTemplateColumns: "300px auto" }}>
        <SideBar />
        <MainContent />
      </div>
      <ComposeGmailModel />
    </div>
  );
}

export default App;
